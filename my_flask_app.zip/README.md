# Flask Deployment on Render

This is a simple Flask web app deployed on Render.

## Run locally
```bash
pip install -r requirements.txt
python app.py
```

## Deploy on Render
1. Push this folder to GitHub
2. Create a new **Web Service** on [Render.com](https://render.com)
3. Connect your GitHub repo
4. Render will auto-detect and deploy 🎉
